// Valide le Web Worker réel (mfkey-worker.js) : cassage + interruption sur délai.
globalThis.self = globalThis;
const messages = [];
globalThis.self.postMessage = (m) => { messages.push(m); };

await import('../flipper-lab-nfc/js/mfkey-worker.js');
const send = (m) => globalThis.self.onmessage({ data: m });

const good = { cuid:0x2a234f80, nt0:0x55721809, nr0:0xce9985f6, ar0:0x772f55be, nt1:0xa27173f2, nr1:0xe386b505, ar1:0x5fa65203 };
const junk = { cuid:0x162a2785, nt0:0x3b42af56, nr0:0xe4b043b5, ar0:0xb55989ff, nt1:0x45d1dfc0, nr1:0x90a75b74, ar1:0x943c009d };

let t = Date.now();
send({ operation: 'start', id: 'a', args: good, timeout: 15 });
await new Promise(r => setTimeout(r, 4000));
console.log(`1. nonce valide  -> ${JSON.stringify(messages.filter(m=>m.operation!=='progress'))} (${Date.now()-t} ms)`);

messages.length = 0; t = Date.now();
send({ operation: 'start', id: 'b', args: junk, timeout: 1 });
await new Promise(r => setTimeout(r, 3000));
console.log(`2. délai 1 s     -> ${JSON.stringify(messages.filter(m=>m.operation!=='progress'))} (${Date.now()-t} ms)`);

messages.length = 0; t = Date.now();
send({ operation: 'start', id: 'c', args: junk, timeout: 15 });
await new Promise(r => setTimeout(r, 300));
send({ operation: 'stop' });
await new Promise(r => setTimeout(r, 1500));
console.log(`3. stop demandé  -> ${JSON.stringify(messages.filter(m=>m.operation!=='progress'))} (${Date.now()-t} ms)`);

messages.length = 0; t = Date.now();
send({ operation: 'start', id: 'd', args: good, timeout: 15 });
await new Promise(r => setTimeout(r, 4000));
console.log(`4. réutilisable  -> ${JSON.stringify(messages.filter(m=>m.operation!=='progress'))} (${Date.now()-t} ms)`);
process.exit(0);
