/**
 * Harnais « Flipper simulé » : valide la couche Web Serial + protobuf RPC,
 * la lecture du journal .mfkey32.log, le cassage, puis la ré-écriture du
 * dictionnaire utilisateur — sans matériel.
 */
import { parseHTML } from 'linkedom';
import { createFakePort, FS, written, FAKE_LOG } from './serial-fake.mjs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import fs from 'node:fs';

const ROOT = fileURLToPath(new URL('../flipper-lab-nfc', import.meta.url));
const engine = await import(`${ROOT}/js/mfkey32.js`);

/* ------------------------------------------------------------------ */
/* environnement DOM                                                   */
/* ------------------------------------------------------------------ */

const { window, document } = parseHTML(fs.readFileSync(`${ROOT}/index.html`, 'utf8'));

class FakeWorker {
  constructor() {
    this.onmessage = null;
  }
  postMessage(data) {
    if (data.operation !== 'start') return;
    setTimeout(() => {
      const started = Date.now();
      let key = null;
      let error = null;
      try {
        key = engine.mfkey32v2(data.args);
      } catch (e) {
        error = e.message;
      }
      this.onmessage?.({
        data: error
          ? { operation: 'error', id: data.id, message: error }
          : { operation: 'output', id: data.id, key, elapsed: Date.now() - started },
      });
    }, 0);
  }
  terminate() {}
}

const fakePort = createFakePort();
const store = new Map();
globalThis.window = window;
globalThis.document = document;
Object.defineProperty(globalThis, 'navigator', {
  configurable: true,
  writable: true,
  value: {
    hardwareConcurrency: 2,
    userAgent: 'node-harness',
    clipboard: { writeText: async () => {} },
    serial: { getPorts: async () => [fakePort], requestPort: async () => fakePort },
  },
});
globalThis.location = { hash: '#/nfc-tools' };
globalThis.localStorage = {
  getItem: (k) => store.get(k) ?? null,
  setItem: (k, val) => store.set(k, String(val)),
  removeItem: (k) => store.delete(k),
};
globalThis.Worker = FakeWorker;
globalThis.Blob = class {
  constructor(parts) {
    this.parts = parts;
  }
};
globalThis.URL.createObjectURL = () => 'blob:fake';
globalThis.URL.revokeObjectURL = () => {};
window.navigator = globalThis.navigator;
window.location = globalThis.location;
window.Worker = FakeWorker;
window.URL = globalThis.URL;
window.Blob = globalThis.Blob;

await import(pathToFileURL(`${ROOT}/js/app.js`).href);
await new Promise((r) => setTimeout(r, 60));

let failures = 0;
const check = (label, ok, extra = '') => {
  if (!ok) failures++;
  console.log(`${ok ? '  ok  ' : ' FAIL '} ${label}${extra ? ' — ' + extra : ''}`);
};
const text = () => document.body.textContent;
const btn = (label) => Array.from(document.querySelectorAll('button')).find((b) => b.textContent.includes(label));

console.log('0. Interface Mfkey32 minimaliste');
check('titre unique Mfkey32', text().includes('Mfkey32'));
check('wordmark en haut à gauche, sans sidebar', !!document.querySelector('.app-topbar__wordmark') && !document.querySelector('.app-sidebar'));
check('commande USB visible', !!btn('Connecter un Flipper'));

console.log('\n1. Connexion au Flipper simulé');
btn('Connecter un Flipper')?.click();
await new Promise((r) => setTimeout(r, 2500));
check('session RPC établie', fakePort.rpcActive());
check('carte appareil affichée', text().includes('Flipper Simulé'), text().match(/Flipper Simulé/)?.[0] ?? '');
check('firmware du Flipper affiché', text().includes('Firmware 0.99.9'));
check('pas d’erreur de connexion', !text().includes('Navigateur non pris en charge'));
check('action de déconnexion disponible', !!btn('Déconnecter'));
check('toujours sans sidebar', !document.querySelector('.app-sidebar'));

console.log('\n2. Lecture du journal sur le Flipper');
check('3 nonces chargés depuis /ext/nfc/.mfkey32.log', /3 nonces/.test(text()) && text().includes('/ext/nfc/.mfkey32.log'));
check('journal rendu en table technique', document.querySelectorAll('.mfkey-nonce-preview tbody tr').length === 3);

console.log('\n3. Cassage + écriture du dictionnaire');
btn('Lancer mfkey32')?.click();
await new Promise((r) => setTimeout(r, 8000));
check('deux clés retrouvées', text().includes('a0a1a2a3a4a5') && text().includes('4d3a99c351dd'), text().match(/Clés uniques : \d+/)?.[0] ?? '');
check('synthèse affichée', /Nonces : 3 \| Clés uniques : 2 \| Nouvelles clés : 1/.test(text()), text().match(/Nonces : [^|]*\|[^|]*\|[^|]*/)?.[0]?.trim() ?? '');
check('dictionnaire existant fusionné', text().includes('Nouvelles clés : 1'), text().match(/Nouvelles clés : \d+/)?.[0] ?? '');
const saveBtn = btn('Enregistrer sur le Flipper');
check('bouton d’écriture proposé', !!saveBtn);
saveBtn?.click();
await new Promise((r) => setTimeout(r, 4000));
const uploaded = written['/ext/nfc/assets/mf_classic_dict_user.nfc'];
const uploadedText = uploaded ? new TextDecoder().decode(new Uint8Array(uploaded.reduce((a, b) => [...a, ...b], []))) : '';
check('dictionnaire écrit sur le Flipper', uploadedText.includes('4d3a99c351dd') && uploadedText.includes('ffffffffffff') && uploadedText.includes('a0a1a2a3a4a5'), uploadedText.replace(/\n/g, '|').slice(0, 90));
check('confirmation affichée', text().includes('Dictionnaire mis à jour sur le Flipper'));

console.log('\n4. Pas de navigation secondaire');
check('Mfkey32 reste l’unique outil', text().includes('Mfkey32') && !document.querySelector('.app-sidebar'));

console.log(failures === 0 ? '\nTous les contrôles passent.' : `\n${failures} contrôle(s) en échec.`);
process.exit(failures === 0 ? 0 : 1);
