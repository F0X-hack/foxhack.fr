#include <stdio.h>
#include <stdint.h>
#include "include/crypto01.h"
int main(){
  struct Crypto1State *s,*t; int n=0;
  uint32_t p64=prng_successor(0x55721809,64);
  s=lfsr_recovery32(0x772f55be ^ p64,0);
  for(t=s;t->odd|t->even;++t) n++;
  printf("ks2=%08x states=%d\n",0x772f55be ^ p64,n);
  return 0;
}
