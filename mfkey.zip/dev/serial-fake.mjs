import * as pb from '../flipper-lab-nfc/js/protobuf.js';
const enc = new TextEncoder();

export const FAKE_LOG = [
  // Journal synthétique : nonces générés côté « tag » pour les clés ci-dessous.
  'Sec 0: cuid 2a234f80 nt0 55721809 nr0 ce9985f6 ar0 772f55be nt1 a27173f2 nr1 e386b505 ar1 5fa65203', // -> a0a1a2a3a4a5
  'Sec 4: cuid 04a224b2 nt0 7ba4eb4a nr0 01cd1d48 ar0 410d4aae nt1 f3beee07 nr1 3dbd1f29 ar1 4d0578e0', // -> 4d3a99c351dd
  'Sec 8: cuid 162a2785 nt0 3b42af56 nr0 e4b043b5 ar0 b55989ff nt1 45d1dfc0 nr1 90a75b74 ar1 943c009d', // nonces aléatoires : aucune clé
].join('\n');

export const FS = {
  '/ext/nfc/.mfkey32.log': enc.encode(FAKE_LOG + '\n'),
  '/ext/nfc/assets/mf_classic_dict_user.nfc': enc.encode('ffffffffffff\na0a1a2a3a4a5\n'),
};

export const written = {};

function frame(commandId, contentName, content, { hasNext = false, status = 0 } = {}) {
  const payload = { commandId, hasNext, commandStatus: status };
  if (status === 0 && contentName) payload[contentName] = content;
  return pb.encodeMainDelimited(payload);
}
function concat(...parts) {
  const total = parts.reduce((a, b) => a + b.length, 0);
  const out = new Uint8Array(total);
  let at = 0;
  for (const p of parts) { out.set(p, at); at += p.length; }
  return out;
}

function respond(msg) {
  const id = msg.commandId;
  if (msg.systemPingRequest) return frame(id, 'systemPingResponse', { data: new Uint8Array(0) });
  if (msg.systemProtobufVersionRequest) return frame(id, 'systemProtobufVersionResponse', { major: 0, minor: 26 });
  if (msg.systemDeviceInfoRequest) {
    const pairs = {
      'hardware.name': 'Flipper Simulé',
      'hardware.model': 'FZ.1',
      'hardware.color': '1',
      'hardware.region': 'eu',
      'hardware.uid': '04112233445566',
      'firmware.version': '0.99.9',
      'firmware.build': 'simulated',
      'firmware.branch': 'dev',
      'hardware.target': 'f7',
      'radio.stack.version': '1.20.0',
    };
    const keys = Object.keys(pairs);
    return concat(
      ...keys.map((k, i) => frame(id, 'systemDeviceInfoResponse', { key: k, value: pairs[k] }, { hasNext: i < keys.length - 1 })),
    );
  }
  if (msg.storageListRequest) {
    const path = msg.storageListRequest.path;
    if (path !== '/ext') return frame(id, null, null, { status: 7 });
    return frame(id, 'storageListResponse', {
      file: ['nfc', 'apps', 'Manifest'].map((name) => ({ type: 0, name, size: 0 })),
    });
  }
  if (msg.storageInfoRequest) {
    const path = msg.storageInfoRequest.path;
    if (path !== '/ext') return frame(id, null, null, { status: 7 });
    return frame(id, 'storageInfoResponse', {
      totalSpace: 16 * 1024 * 1024 * 1024,
      freeSpace: 9 * 1024 * 1024 * 1024,
    });
  }
  if (msg.storageReadRequest) {
    const path = msg.storageReadRequest.path;
    const data = FS[path];
    if (!data) return frame(id, null, null, { status: 7 });
    const CHUNK = 128;
    const out = [];
    for (let off = 0; off < data.length; off += CHUNK) {
      out.push(
        frame(
          id,
          'storageReadResponse',
          { file: { type: 1, name: path.split('/').pop(), size: data.length, data: data.subarray(off, off + CHUNK) } },
          { hasNext: off + CHUNK < data.length },
        ),
      );
    }
    return concat(...out);
  }
  if (msg.storageWriteRequest) {
    const path = msg.storageWriteRequest.path;
    const chunk = msg.storageWriteRequest.file?.data ?? new Uint8Array(0);
    written[path] = written[path] ?? [];
    written[path].push(chunk);
    return frame(id, null, null);
  }
  if (msg.storageStatRequest) {
    const path = msg.storageStatRequest.path;
    const data = FS[path];
    if (!data) return frame(id, null, null, { status: 7 });
    return frame(id, 'storageStatResponse', {
      file: { type: 1, name: path.split('/').pop(), size: data.length },
    });
  }
  return frame(id, null, null, { status: 3 });
}

/* ------------------------------------------------------------------ */
/* port série factice                                                  */
/* ------------------------------------------------------------------ */

function createFakePort() {
  let pushToMain = () => {};
  let rpcMode = false;
  const queue = [];
  const closed = { value: false };

  const readable = {
    getReader() {
      return {
        async read() {
          for (;;) {
            if (closed.value) return { value: undefined, done: true };
            if (queue.length) return { value: queue.shift(), done: false };
            await new Promise((r) => {
              pushToMain = r;
              setTimeout(r, 40);
            });
          }
        },
        cancel: async () => {},
        releaseLock() {},
      };
    },
  };

  const writable = {
    getWriter() {
      return {
        async write(data) {
          const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
          const text = new TextDecoder().decode(bytes);
          if (!rpcMode && text.includes('start_rpc_session')) {
            rpcMode = true;
            queue.push(enc.encode('start_rpc_session\r'));
            pushToMain();
            return;
          }
          if (!rpcMode) return;
          const { messages } = pb.drainDelimited(bytes);
          if (globalThis.__FAKE_DEBUG) console.log('[fake] reçoit', messages.length, 'trame(s)', JSON.stringify(messages).slice(0, 200));
          for (const msg of messages) {
            try {
              const answer = respond(msg);
              if (answer?.length) queue.push(answer);
              if (globalThis.__FAKE_DEBUG) console.log('[fake] répond', answer?.length ?? 0, 'octets', Buffer.from(answer ?? []).toString('hex').slice(0, 160));
            } catch (e) {
              console.log('[fake] ERREUR respond :', e.message);
            }
          }
          pushToMain();
        },
        releaseLock() {},
      };
    },
  };

  return {
    readable,
    writable,
    getInfo: () => ({ usbVendorId: 0x0483, usbProductId: 0x5740 }),
    async open() {
      closed.value = false;
    },
    async close() {
      closed.value = true;
    },
    rpcActive: () => rpcMode,
  };
}


export { createFakePort };
