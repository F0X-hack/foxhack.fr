/**
 * Harnais de test : exécute l'application dans un DOM simulé (linkedom) avec un
 * « Worker » synchrone branché sur le moteur mfkey32, pour valider le rendu et
 * les deux pipelines (hors ligne + manuel) sans navigateur.
 *
 * Usage : node harness.mjs
 */
import { parseHTML } from 'linkedom';
import { EventEmitter } from 'node:events';
import { fileURLToPath, pathToFileURL } from 'node:url';
import fs from 'node:fs';

const ROOT = fileURLToPath(new URL('../flipper-lab-nfc', import.meta.url));
const html = fs.readFileSync(`${ROOT}/index.html`, 'utf8');
const { window, document } = parseHTML(html);

const engine = await import(`${ROOT}/js/mfkey32.js`);

class FakeWorker {
  constructor() {
    this.bus = new EventEmitter();
    this.onmessage = null;
    this.onerror = null;
  }
  postMessage(data) {
    if (data.operation !== 'start') return;
    setTimeout(() => {
      const started = Date.now();
      let key = null;
      let error = null;
      try {
        key = engine.mfkey32v2(data.args);
      } catch (e) {
        error = e.message;
      }
      this.onmessage?.({
        data: error
          ? { operation: 'error', id: data.id, message: error, elapsed: Date.now() - started }
          : { operation: 'output', id: data.id, key, elapsed: Date.now() - started },
      });
    }, 0);
  }
  terminate() {}
}

const store = new Map();
const WITH_SERIAL = process.argv.includes('--serial');

globalThis.window = window;
globalThis.document = document;
Object.defineProperty(globalThis, 'navigator', {
  configurable: true,
  writable: true,
  value: {
    hardwareConcurrency: 2,
    userAgent: 'node-harness',
    clipboard: { writeText: async () => {} },
    ...(WITH_SERIAL ? { serial: { getPorts: async () => [], requestPort: async () => { throw new Error('no port'); } } } : {}),
  },
});
globalThis.location = { hash: '#/nfc-tools', href: 'http://localhost/' };
globalThis.localStorage = {
  getItem: (k) => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => store.set(k, String(v)),
  removeItem: (k) => store.delete(k),
};
globalThis.Worker = FakeWorker;
globalThis.Blob = class { constructor(parts) { this.parts = parts; } };
globalThis.URL.createObjectURL = () => 'blob:fake';
globalThis.URL.revokeObjectURL = () => {};
window.location = globalThis.location;
window.navigator = globalThis.navigator;
window.Worker = FakeWorker;
window.URL = globalThis.URL;
window.Blob = globalThis.Blob;

const errors = [];
const realError = console.error;
console.error = (...a) => { errors.push(a.join(' ')); realError(...a); };

await import(pathToFileURL(`${ROOT}/js/app.js`).href);
await new Promise((r) => setTimeout(r, 60));

let failures = 0;
const check = (label, ok, extra = '') => {
  if (!ok) failures++;
  console.log(`${ok ? '  ok  ' : ' FAIL '} ${label}${extra ? ' — ' + extra : ''}`);
};

console.log('1. Workbench Mfkey32');
const text = () => document.body.textContent;
check('titre Mfkey32', text().includes('Mfkey32'));
check('topbar technique sans sidebar', !!document.querySelector('.app-topbar') && !document.querySelector('.app-sidebar'));
check('wordmark FoXhack en haut à gauche', document.querySelector('.app-topbar__brand .app-topbar__wordmark')?.getAttribute('src') === 'https://foxhack.fr/brand/foxhack-wordmark.svg');
check('fil d’Ariane Mfkey32', document.querySelector('.app-topbar__breadcrumb strong')?.textContent === 'MFKey32');
check('deux panneaux visibles', !!document.querySelector('#card-flipper') && !!document.querySelector('#card-manual') && !document.querySelector('#mode-manual'));
check('tutoriel de nonces placé sous les panneaux', document.querySelector('.mfkey-tutorial')?.previousElementSibling?.classList.contains('mfkey-panel-grid') === true);
check('illustration NFC accessible et cadrée pour mobile', document.querySelector('.mfkey-tutorial__art > .mfkey-tutorial__image')?.getAttribute('src') === 'assets/reader.png' && !!document.querySelector('.mfkey-tutorial__image')?.getAttribute('alt'));
check('aucune sidebar ni navigation générique', !document.querySelector('.app-sidebar, .app-drawer, .nav-links'));
check('en-tête Journal de nonces', text().includes('Journal de nonces'));
check('panneau de saisie manuelle', text().includes('Saisie manuelle'));
check('7 champs de nonce', document.querySelectorAll('.args-inputs-container .q-field').length === 7,
  `${document.querySelectorAll('.args-inputs-container .q-field').length} trouvés`);
check('journal fichier hors ligne', text().includes('mfkey32.log'));
check('indication de connexion USB', text().includes('Chrome ou Edge sur ordinateur'));

console.log('\n2. Mode hors ligne : collage d’un journal');
{
  const log = [
    'cuid 2a234f80 nt0 55721809 nr0 ce9985f6 ar0 772f55be nt1 a27173f2 nr1 e386b505 ar1 5fa65203',
    'cuid 162a2785 nt0 3b42af56 nr0 e4b043b5 ar0 b55989ff nt1 45d1dfc0 nr1 90a75b74 ar1 943c009d',
    'cuid d92e333a nt0 66f2f387 nr0 e48e5936 ar0 f126635e nt1 d5b3406c nr1 fcf383f9 ar1 69441f81',
  ].join('\n');
  const pasteBtn = Array.from(document.querySelectorAll('button')).find((b) => b.textContent.includes('Coller un journal'));
  check('bouton « Coller un journal »', !!pasteBtn);
  pasteBtn?.click();
  await new Promise((r) => setTimeout(r, 30));
  const area = document.querySelector('.q-dialog textarea');
  check('zone de texte du dialogue', !!area);
  if (area) {
    area.value = log;
    const go = Array.from(document.querySelectorAll('.q-dialog button')).find((b) => b.textContent.trim() === 'Analyser');
    go?.click();
    await new Promise((r) => setTimeout(r, 60));
    check('3 nonces chargés', /3 nonces/.test(text()), text().match(/\d+ nonce/)?.[0] ?? '');
    check('aperçu tabulaire des nonces', document.querySelectorAll('.mfkey-nonce-preview tbody tr').length === 3);
    const run = Array.from(document.querySelectorAll('button')).find((b) => b.textContent.includes('Lancer mfkey32'));
    check('bouton « Lancer mfkey32 » actif', !!run && !run.disabled);
    run?.click();
    await new Promise((r) => setTimeout(r, 6000));
    check('clé retrouvée affichée', text().includes('a0a1a2a3a4a5'));
    check('compte rendu (nonces / clés / délais)', /Nonces : 3/.test(text()) && /Clés uniques : 1/.test(text()));
    check('encadré de synthèse', /Cassage terminé/.test(text()) && /Nonces : 3/.test(text()));
    check('téléchargement du dictionnaire proposé', text().includes('Télécharger le dictionnaire'));
  }
}

console.log('\n3. Attaque manuelle (vecteur de test)');
{
  const form = document.querySelector('#card-manual form');
  const ev = new (window.Event ?? globalThis.Event)('submit', { bubbles: true, cancelable: true });
  form.dispatchEvent(ev);
  await new Promise((r) => setTimeout(r, 3000));
  const out = document.querySelector('#manual-result')?.textContent ?? '';
  check('clé affichée', out.includes('a0a1a2a3a4a5'), out.slice(0, 80));
}

console.log('\n4. Navigation de l’outil unique');
{
  globalThis.location.hash = '#/apps';
  window.dispatchEvent(new (window.Event ?? globalThis.Event)('hashchange'));
  await new Promise((r) => setTimeout(r, 30));
  check('Mfkey32 reste le seul outil', text().includes('Mfkey32') && !document.querySelector('.app-sidebar'));
  check('les panneaux restent accessibles', !!document.querySelector('#card-flipper') && !!document.querySelector('#card-manual'));
}

console.log('\n5. Erreurs console');
check('aucune erreur console', errors.length === 0, errors.slice(0, 3).join(' | '));

console.log(failures === 0 ? '\nTous les contrôles passent.' : `\n${failures} contrôle(s) en échec.`);
process.exit(failures === 0 ? 0 : 1);
