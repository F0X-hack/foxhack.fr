/**
 * Tests du moteur mfkey32v2 : comparaison systématique avec le binaire C de
 * référence (compilé depuis github.com/equipter/mfkey32v2 + crypto01 de
 * Proxmark3) et aller-retour clé → nonces → clé sur des nonces synthétiques.
 *
 * Usage : node test.mjs
 */
import { execFileSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import {
  mfkey32v2,
  parseMfkeyLog,
  crypto1Init,
  crypto1Word,
  crypto1GetLfsr,
  prngSuccessor,
  mergeDictionary,
} from './mfkey32.mjs';

const C_BIN = new URL('./ref/mfkey32v2', import.meta.url).pathname;
const hex = (n, w = 8) => (n >>> 0).toString(16).padStart(w, '0');

/** Génère le quart d'authentification émis par une carte MIFARE Classic. */
function synthTagSide(keyHex, cuid) {
  const nt = (Math.random() * 0xffffffff) >>> 0;
  const nr = (Math.random() * 0xffffffff) >>> 0;
  const s = { odd: 0, even: 0 };
  crypto1Init(s, keyHex);
  crypto1Word(s, (cuid ^ nt) >>> 0, 0); // ks0
  const ks1 = crypto1Word(s, nr, 0);
  const nrEnc = (nr ^ ks1) >>> 0; // {nr} tel qu'observé sur l'air
  const ks2 = crypto1Word(s, 0, 0);
  const arEnc = (ks2 ^ prngSuccessor(nt, 64)) >>> 0; // {ar}
  return { nt, nrEnc, arEnc };
}

function runC(values) {
  if (!existsSync(C_BIN)) return undefined;
  const out = execFileSync(C_BIN, values.map((v) => hex(v)), { encoding: 'utf8' });
  const m = out.match(/Found Key: \[([0-9a-f]{12})\]/);
  return m ? m[1] : null;
}

let failures = 0;
const check = (label, got, expected) => {
  const ok = got === expected;
  if (!ok) failures++;
  console.log(`  ${ok ? 'ok  ' : 'FAIL'} ${label} : ${got ?? 'null'}${ok ? '' : ` (attendu ${expected ?? 'null'})`}`);
};

console.log('1. Vecteur public (pré-rempli dans le formulaire de lab.flipper.net)');
{
  const line = 'cuid 2a234f80 nt0 55721809 nr0 ce9985f6 ar0 772f55be nt1 a27173f2 nr1 e386b505 ar1 5fa65203';
  const { args } = parseMfkeyLog(line)[0];
  const t = Date.now();
  const key = mfkey32v2(args);
  check(`clé retrouvée (${Date.now() - t} ms)`, key, 'a0a1a2a3a4a5');
  if (existsSync(C_BIN)) check('identique au binaire C', key, runC(Object.values(args)));
}

console.log('2. Nonces incohérents (aucune clé attendue)');
for (const line of [
  'cuid 162a2785 nt0 3b42af56 nr0 e4b043b5 ar0 b55989ff nt1 45d1dfc0 nr1 90a75b74 ar1 943c009d',
  'cuid d92e333a nt0 66f2f387 nr0 e48e5936 ar0 f126635e nt1 d5b3406c nr1 fcf383f9 ar1 69441f81',
]) {
  const { args } = parseMfkeyLog(line)[0];
  const key = mfkey32v2(args);
  check(`JS (${line.slice(5, 22)}…)`, key, null);
  if (existsSync(C_BIN)) check('identique au binaire C', key, runC(Object.values(args)));
}

console.log('3. Aller-retour clé → nonces → clé');
{
  const keys = ['ffffffffffff', 'a0a1a2a3a4a5', '000000000000', 'd3f7d3f7d3f7', '4d3a99c351dd', '1a982c7e459a', '048920e28367'];
  let total = 0;
  let ok = 0;
  for (const key of keys) {
    const cuid = (Math.random() * 0xffffffff) >>> 0;
    const a = synthTagSide(key, cuid);
    const b = synthTagSide(key, cuid);
    const args = { cuid, nt0: a.nt, nr0: a.nrEnc, ar0: a.arEnc, nt1: b.nt, nr1: b.nrEnc, ar1: b.arEnc };
    const t = Date.now();
    const found = mfkey32v2(args);
    const dt = Date.now() - t;
    total += dt;
    if (found === key) ok++;
    else failures++;
    const ref = existsSync(C_BIN) ? runC(Object.values(args)) : undefined;
    console.log(`  ${found === key ? 'ok  ' : 'FAIL'} ${key} → ${found ?? 'null'} (${dt} ms)${ref !== undefined ? ` | C : ${ref ?? 'null'}` : ''}`);
    if (ref !== undefined && ref !== found) failures++;
  }
  console.log(`  ${ok}/${keys.length} clés retrouvées, ${total} ms au total, ${Math.round(total / keys.length)} ms par attaque`);
}

console.log('4. Utilitaires');
{
  const log = `2024-06-01 12:00:00 cuid 2a234f80 nt0 55721809 nr0 ce9985f6 ar0 772f55be nt1 a27173f2 nr1 e386b505 ar1 5fa65203
Sec 4: cuid 04a224b2 nt0 7ba4eb4a nr0 01cd1d48 ar0 410d4aae nt1 f3beee07 nr1 3dbd1f29 ar1 4d0578e0
cuid 162a2785 nt0 3b42af56 nr0 e4b043b5 ar0 b55989ff nt1 45d1dfc0 nr1 90a75b74 ar1 943c009d
ligne parasite sans nonce`;
  check('parseMfkeyLog (3 entrées)', parseMfkeyLog(log).length, 3);
  const merged = mergeDictionary('ffffffffffff\na0a1a2a3a4a5\nError: mfkey run killed on timeout\n', ['a0a1a2a3a4a5', '000000000000']);
  check('mergeDictionary (total)', merged.total, 3);
  check('mergeDictionary (ajouts)', merged.added, 1);
  const s = { odd: 0, even: 0 };
  crypto1Init(s, 'a0a1a2a3a4a5');
  check('crypto1_init/get_lfsr', crypto1GetLfsr(s).toString(16), 'a0a1a2a3a4a5');
  check('prng_successor', hex(prngSuccessor(0x55721809, 64)), 'ce3062eb');
}

console.log(failures === 0 ? '\nTous les tests passent.' : `\n${failures} échec(s).`);
process.exit(failures === 0 ? 0 : 1);
