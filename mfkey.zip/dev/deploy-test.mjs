/**
 * Banc « mise en ligne » : vérifie que le dossier livré peut être déposé tel
 * quel sur un hébergement statique (ex. https://foxhack.fr/mfkey32) sans écran
 * noir — le piège classique étant un serveur qui renvoie les scripts ES avec un
 * type MIME autre que « text/javascript ».
 *
 * Contrôle :
 *   1. aucune référence .mjs dans le livrable (MIME inconnu sur mutualisé),
 *   2. tous les fichiers référencés par index.html et par les modules existent,
 *   3. .htaccess présent et porteur des AddType nécessaires,
 *   4. le garde-fou de index.html affiche un diagnostic au lieu d’un écran noir
 *      quand un module est refusé (MIME octet-stream) ou introuvable (404),
 *   5. le garde-fou s’efface dès que l’application est montée.
 *
 * Usage : node deploy-test.mjs
 */
import { parseHTML } from 'linkedom';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = fileURLToPath(new URL('../flipper-lab-nfc', import.meta.url));
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const html = read('index.html');

let failures = 0;
const check = (label, ok, extra = '') => {
  if (!ok) failures++;
  console.log(`${ok ? '  ok  ' : ' FAIL '} ${label}${extra ? ' — ' + extra : ''}`);
};

/* ------------------------------------------------------------------ */
/* 1. Livrable sans extension à risque                                  */
/* ------------------------------------------------------------------ */

console.log('1. Livrable statique');
{
  const walk = (dir) =>
    fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
      const full = path.join(dir, entry.name);
      return entry.isDirectory() ? walk(full) : [full];
    });
  const files = walk(ROOT).map((f) => path.relative(ROOT, f));
  const risky = files.filter((f) => /\.(mjs|mts|jsx|ts|tsx)$/.test(f));
  check('aucun fichier .mjs/.ts dans le livrable', risky.length === 0, risky.join(', '));
  check('moteur livré en mfkey32.js', files.includes('js/mfkey32.js'));
  check(
    'aucun module .mjs référencé par index.html',
    !/(?:src|href)=["'][^"']*\.mjs|import\(\s*['"][^'"]*\.mjs/.test(html)
  );

  const jsFiles = files.filter((f) => f.startsWith('js/'));
  const badRefs = [];
  for (const file of jsFiles) {
    for (const m of read(file).matchAll(/(?:from|import)\s*\(?\s*'\.\/([^']+)'/g)) {
      const target = path.posix.join(path.posix.dirname(file), m[1].split('?')[0]);
      if (!files.includes(target)) badRefs.push(`${file} -> ${m[1]}`);
      else if (!target.endsWith('.js')) badRefs.push(`${file} -> ${m[1]} (extension non .js)`);
    }
  }
  check('imports des modules résolus et en .js', badRefs.length === 0, badRefs.join(', '));

  const versions = [...html.matchAll(/\?v=([A-Za-z0-9._-]+)/g)].map((m) => m[1]);
  check(
    'cache-busting homogène',
    versions.length > 0 && versions.every((v) => v === versions[0]),
    [...new Set(versions)].join(', ')
  );
}

/* ------------------------------------------------------------------ */
/* 2. Fichiers référencés présents sur le disque                        */
/* ------------------------------------------------------------------ */

console.log('\n2. Références locales de index.html');
{
  const refs = [...html.matchAll(/(?:href|src)="([^"?:]+)(?:\?[^"]*)?"/g)]
    .map((m) => m[1])
    .filter((ref) => !/^(https?:|data:|blob:|#|mailto:)/.test(ref));
  check('références locales trouvées', refs.length >= 2, refs.join(', '));
  const missing = refs.filter((ref) => !fs.existsSync(path.join(ROOT, ref)));
  check('toutes présentes sur le disque', missing.length === 0, missing.join(', '));
  check('références relatives (sous-dossier /mfkey32)', refs.every((ref) => !ref.startsWith('/')), refs.filter((r) => r.startsWith('/')).join(', '));
  check('.htaccess livré', fs.existsSync(path.join(ROOT, '.htaccess')));
  const htaccess = fs.existsSync(path.join(ROOT, '.htaccess')) ? read('.htaccess') : '';
  check('.htaccess : AddType text/javascript .js .mjs', /AddType\s+text\/javascript\s+\.js\s+\.mjs/.test(htaccess));
  let depth = 0;
  const unprotected = [];
  for (const raw of htaccess.split('\n')) {
    const line = raw.trim();
    if (/^<IfModule/i.test(line)) depth += 1;
    else if (/^<\/IfModule>/i.test(line)) depth = Math.max(0, depth - 1);
    else if (line && !line.startsWith('#') && /^(AddType|DirectoryIndex|Header|Rewrite)/i.test(line) && depth === 0) {
      unprotected.push(line);
    }
  }
  check('.htaccess : directives protégées par <IfModule>', unprotected.length === 0, unprotected.join(' | '));
}

/* ------------------------------------------------------------------ */
/* 3. Garde-fou de démarrage (DOM simulé)                               */
/* ------------------------------------------------------------------ */

const GUARD = (() => {
  const m = html.match(/<script>\s*([\s\S]*?)\s*<\/script>/);
  if (!m) throw new Error('script de garde-fou introuvable dans index.html');
  return m[1];
})();

/**
 * Exécute le garde-fou dans un DOM simulé. `responses` décrit ce que le serveur
 * renverrait : { 'js/app.js': { status, type } } — par défaut tout est en
 * « application/octet-stream », comme sur un mutualisé qui ignore .mjs.
 */
async function bootGuard({ responses = {}, bootTimeout = 60, wait = 200 } = {}) {
  const { window, document } = parseHTML(html);
  const probes = [];
  const fakeFetch = (url) => {
    const file = String(url).split('?')[0];
    probes.push(file);
    const answer = responses[file] ?? { status: 200, type: 'application/octet-stream' };
    return Promise.resolve({
      status: answer.status,
      headers: { get: (name) => (name.toLowerCase() === 'content-type' ? answer.type : null) },
    });
  };

  globalThis.window = window;
  globalThis.document = document;
  globalThis.fetch = fakeFetch;
  Object.defineProperty(globalThis, 'navigator', {
    configurable: true,
    writable: true,
    value: { clipboard: { writeText: async () => {} } },
  });
  globalThis.location = { reload: () => {}, href: 'https://foxhack.fr/mfkey32/' };
  window.navigator = globalThis.navigator;
  window.location = globalThis.location;
  window.fetch = fakeFetch;
  window.__mfkeyBootTimeout = bootTimeout;

  (0, eval)(GUARD);
  await new Promise((r) => setTimeout(r, wait));
  return { window, document, probes, guard: window.__mfkeyGuard };
}

const MIME_ERROR =
  'Failed to load module script: Expected a JavaScript-or-Wasm module script but the ' +
  'server responded with a MIME type of "application/octet-stream". Strict MIME type ' +
  'checking is enforced for module scripts per HTML spec.';

console.log('\n3. Garde-fou : MIME refusé par le navigateur');
{
  const { document, guard } = await bootGuard();
  check('le module principal charge js/app.js', /import\(['"]\.\/js\/app\.js\?v=/.test(html));
  check('échec d’import transmis au garde-fou', /__mfkeyGuard\.fail\(error\)/.test(html.replace(/\s+/g, ' ')));

  guard.fail(new TypeError(MIME_ERROR));
  await new Promise((r) => setTimeout(r, 30));

  const text = document.body.textContent;
  check('pas d’écran noir : diagnostic rendu', text.length > 200, `${text.length} caractères`);
  check('cause MIME annoncée', /MIME/.test(text) && /text\/javascript/.test(text));
  check('message d’origine détaillé', /octet-stream/.test(text));
  check('correctif .htaccess affiché', /AddType text\/javascript \.js \.mjs/.test(text));
  check('diagnostic par fichier', /js\/mfkey32\.js/.test(text) && /MIME invalide/.test(text));
  check('bouton de copie du correctif', !!document.getElementById('__mfkey-copy'));
  check('bouton de rechargement', !!document.getElementById('__mfkey-reload'));
  check('le garde-fou ne s’affiche qu’une fois', (guard.fail(new Error('x')), document.querySelectorAll('h1').length === 1));
}

console.log('\n4. Garde-fou : fichier manquant (404)');
{
  const { document, guard, probes } = await bootGuard({
    responses: {
      'js/app.js': { status: 200, type: 'text/javascript' },
      'js/mfkey32.js': { status: 404, type: 'text/html' },
      'js/mfkey-worker.js': { status: 200, type: 'text/javascript' },
      'js/flipper-serial.js': { status: 200, type: 'text/javascript' },
      'js/protobuf.js': { status: 200, type: 'text/javascript' },
      'js/icons.js': { status: 200, type: 'text/javascript' },
    },
  });
  guard.fail(new Error('error loading dynamically imported module'));
  await new Promise((r) => setTimeout(r, 30));
  const text = document.body.textContent;
  check('tous les modules sondés', probes.length === 6, probes.join(', '));
  check('fichier manquant signalé', /introuvable \(HTTP 404\)/.test(text));
  check('scripts sains marqués OK', /OK — text\/javascript/.test(text));
}

console.log('\n5. Garde-fou : serveur correct');
{
  const ok = { status: 200, type: 'text/javascript' };
  const { document, guard } = await bootGuard({
    responses: {
      'js/app.js': ok,
      'js/mfkey32.js': ok,
      'js/mfkey-worker.js': ok,
      'js/flipper-serial.js': ok,
      'js/protobuf.js': ok,
      'js/icons.js': ok,
    },
  });
  guard.fail(new Error('boom'));
  await new Promise((r) => setTimeout(r, 30));
  const probe = document.getElementById('__mfkey-probe')?.textContent ?? '';
  check('piste cache/chemin proposée quand les MIME sont bons', /Ctrl\+F5/.test(document.body.textContent));
  check('aucun faux positif au diagnostic', probe.includes('OK') && !/MIME invalide|introuvable|non chargé/.test(probe), probe.slice(0, 120));
}

console.log('\n6. Garde-fou : application montée');
{
  const { document, guard, window } = await bootGuard({ wait: 0 });
  guard.ready();
  const shell = document.createElement('div');
  shell.className = 'app-shell';
  document.body.append(shell);
  window.dispatchEvent(new window.Event('error'));
  await new Promise((r) => setTimeout(r, 200));
  check('aucun diagnostic après ready()', !document.getElementById('__mfkey-copy'));
  check('interface intacte', !!document.querySelector('.app-shell'));
}

console.log('\n7. Filet de sécurité temporel');
{
  const { document } = await bootGuard({ bootTimeout: 60, wait: 300 });
  check('diagnostic automatique si rien ne monte', /pas démarré|pas pu démarrer/.test(document.body.textContent), document.body.textContent.slice(0, 90));
}
{
  const { document, guard } = await bootGuard({ bootTimeout: 60, wait: 0 });
  guard.ready();
  await new Promise((r) => setTimeout(r, 200));
  check('filet désarmé une fois l’app prête', !document.getElementById('__mfkey-htaccess'));
}
{
  // Réseau lent : le filet se déclenche, puis l’application démarre quand même.
  const { document, guard } = await bootGuard({ bootTimeout: 40, wait: 150 });
  check('panneau affiché pendant le chargement lent', !!document.getElementById('__mfkey-htaccess'));
  guard.ready();
  await new Promise((r) => setTimeout(r, 20));
  check('panneau retiré au démarrage effectif', !document.getElementById('__mfkey-htaccess'));
  check('conteneur d’app rendu vide', (document.getElementById('q-app')?.innerHTML ?? '').trim() === '');
}

console.log(failures === 0 ? '\nTous les contrôles passent.' : `\n${failures} contrôle(s) en échec.`);
process.exit(failures === 0 ? 0 : 1);
