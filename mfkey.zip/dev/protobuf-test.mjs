/**
 * Tests du codec protobuf minimal (js/protobuf.js) : aller-retour encodage /
 * décodage, champs répétés, trames enchaînées, trame partielle, codes d'erreur.
 *
 * Usage : node protobuf-test.mjs
 */
import * as pb from '../flipper-lab-nfc/js/protobuf.js';

let failures = 0;
const check = (label, got, expected) => {
  const a = JSON.stringify(got);
  const b = JSON.stringify(expected);
  const ok = a === b;
  if (!ok) failures++;
  console.log(`  ${ok ? 'ok  ' : 'FAIL'} ${label}${ok ? '' : `\n        obtenu   ${a}\n        attendu  ${b}`}`);
};
const hex = (u) => Buffer.from(u).toString('hex');

console.log('1. Varint');
{
  const out = [];
  pb.writeVarint(out, 0);
  check('varint(0)', out, [0]);
  const out2 = [];
  pb.writeVarint(out2, 300);
  check('varint(300)', out2, [0xac, 0x02]);
  const out3 = [];
  pb.writeVarint(out3, 16 * 1024 * 1024 * 1024);
  check('varint(16 Gio) sur 5 octets', out3.length, 5);
}

console.log('2. Numéros de champs PB.Main');
check('commandId = 1', pb.PB_MAIN_FIELDS[1], 'commandId');
check('storageReadRequest = 9', pb.PB_MAIN_FIELDS[9], 'storageReadRequest');
check('storageReadResponse = 10', pb.PB_MAIN_FIELDS[10], 'storageReadResponse');
check('systemDeviceInfoResponse = 33', pb.PB_MAIN_FIELDS[33], 'systemDeviceInfoResponse');
check('storageWriteRequest = 11', pb.PB_MAIN_FIELDS[11], 'storageWriteRequest');

console.log('3. Aller-retour requête');
{
  const frame = pb.encodeMainDelimited({ commandId: 42, storageReadRequest: { path: '/ext/nfc/.mfkey32.log' } });
  const { messages, rest } = pb.drainDelimited(frame);
  check('une trame, aucun reste', [messages.length, rest.length], [1, 0]);
  check('commandId', messages[0].commandId, 42);
  check('hasNext', messages[0].hasNext, false);
  check('chemin', messages[0].storageReadRequest.path, '/ext/nfc/.mfkey32.log');
}

console.log('4. Aller-retour réponse avec données binaires');
{
  const data = new Uint8Array([0, 1, 10, 13, 0x29, 0xff, 0x80]);
  const frame = pb.encodeMainDelimited({
    commandId: 7,
    hasNext: true,
    storageReadResponse: { file: { type: 1, name: 'log', size: data.length, data } },
  });
  const msg = pb.drainDelimited(frame).messages[0];
  check('hasNext', msg.hasNext, true);
  check('type de fichier', msg.storageReadResponse.file.typeName, 'FILE');
  check('nom', msg.storageReadResponse.file.name, 'log');
  check('octets', Array.from(msg.storageReadResponse.file.data), Array.from(data));
}

console.log('5. Champs répétés dans une même trame');
{
  const frame = pb.encodeMainDelimited({
    commandId: 9,
    hasNext: true,
    systemDeviceInfoResponse: [
      { key: 'hardware.name', value: 'Flipper Zero' },
      { key: 'firmware.version', value: '0.99.9' },
    ],
  });
  const msg = pb.drainDelimited(frame).messages[0];
  check('deux occurrences conservées', Array.isArray(msg.systemDeviceInfoResponse), true);
  check('paires', msg.systemDeviceInfoResponse.map((p) => [p.key, p.value]), [['hardware.name', 'Flipper Zero'], ['firmware.version', '0.99.9']]);
}

console.log('6. Liste de fichiers');
{
  const frame = pb.encodeMainDelimited({
    commandId: 3,
    storageListResponse: { file: [{ type: 0, name: 'nfc' }, { type: 1, name: 'Manifest', size: 12 }] },
  });
  const msg = pb.drainDelimited(frame).messages[0];
  check('2 entrées', msg.storageListResponse.file.length, 2);
  check('types', msg.storageListResponse.file.map((f) => f.typeName), ['DIR', 'FILE']);
}

console.log('7. Trames enchaînées et trame partielle');
{
  const a = pb.encodeMainDelimited({ commandId: 1, systemPingRequest: { data: new Uint8Array(0) } });
  const b = pb.encodeMainDelimited({ commandId: 2, commandStatus: 0 });
  const both = new Uint8Array([...a, ...b]);
  check('deux trames décodées', pb.drainDelimited(both).messages.length, 2);
  const cut = both.slice(0, a.length + 3);
  const res = pb.drainDelimited(cut);
  check('trame tronquée mise de côté', [res.messages.length, res.rest.length], [1, 3]);
  const completed = pb.drainDelimited(new Uint8Array([...res.rest, ...both.slice(a.length + 3)]));
  check('complétée au bloc suivant', completed.messages.length, 1);
}

console.log('8. Codes d’erreur');
{
  const frame = pb.encodeMainDelimited({ commandId: 5, commandStatus: 7 });
  check('ERROR_STORAGE_NOT_EXIST', pb.drainDelimited(frame).messages[0].commandStatusName, 'ERROR_STORAGE_NOT_EXIST');
  const busy = pb.encodeMainDelimited({ commandId: 5, commandStatus: 4 });
  check('ERROR_BUSY', pb.drainDelimited(busy).messages[0].commandStatusName, 'ERROR_BUSY');
}

console.log('9. Espaces de stockage en uint64');
{
  const frame = pb.encodeMainDelimited({
    commandId: 8,
    storageInfoResponse: { totalSpace: 16 * 1024 ** 3, freeSpace: 9 * 1024 ** 3 },
  });
  const msg = pb.drainDelimited(frame).messages[0];
  check('totalSpace', msg.storageInfoResponse.totalSpace, 16 * 1024 ** 3);
  check('freeSpace', msg.storageInfoResponse.freeSpace, 9 * 1024 ** 3);
}

console.log('10. Ambiguïté texte / protobuf');
{
  // 0x0a est à la fois LF et un préfixe de longueur valide (10 octets) :
  // la trame doit survivre telle quelle au décodage.
  const frame = pb.encodeMainDelimited({ commandId: 1, systemPingResponse: { data: new Uint8Array(0) } });
  check('préfixe 0x0a intact', hex(frame).startsWith('0a'), true);
  check('décodée', pb.drainDelimited(frame).messages[0].commandId, 1);
}

console.log(failures === 0 ? '\nTous les tests passent.' : `\n${failures} échec(s).`);
process.exit(failures === 0 ? 0 : 1);
