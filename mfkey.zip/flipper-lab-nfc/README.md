# Mfkey32 — FoXhack

Application indépendante pour lancer **Mfkey32** depuis un navigateur, inspirée du labo [FoXhack](https://foxhack.fr) et de l’outil [lab.flipper.net](https://lab.flipper.net/nfc-tools).

L’interface est un workbench compact dédié à Mfkey32 : wordmark FoXhack en haut à gauche, barre supérieure discrète et panneaux techniques denses, sans sidebar. Le thème graphite utilise un seul accent orange, sans hero marketing ni éléments décoratifs superflus. Le calcul cryptographique s’exécute localement dans le navigateur et aucun nonce ni aucune clé ne quitte la machine.

Aucune dépendance runtime : HTML, CSS et JavaScript vanilla (modules ES), servis par un mini-serveur Python.

---

## Démarrage

```bash
cd flipper-lab-nfc
python3 server.py 8080
# → http://localhost:8080/
```

Le serveur renvoie la page Mfkey32 pour les routes inconnues, mais l’application elle-même reste une page unique, sans routage client.

> **Connexion au Flipper** : l’API Web Serial exige un contexte sécurisé (`https://` ou `localhost`) et un navigateur Chromium sur ordinateur (Chrome, Edge, Opera ou Brave). Safari et Firefox ne l’implémentent pas ; l’import d’un fichier et le collage d’un journal restent disponibles hors ligne.

---

## Fonctionnalités

| Fonction | Détail |
| --- | --- |
| Journal / Flipper | Connexion USB Web Serial, lecture du journal et du dictionnaire utilisateur, calcul, puis écriture des nouvelles clés sur le Flipper |
| Saisie manuelle | Sept valeurs hexadécimales pour deux authentifications, avec un vecteur de test prérempli |
| Mode hors ligne | Import ou dépôt d’un fichier `.mfkey32.log`, ou collage de son contenu |
| Résultats | Progression, clés trouvées, délais dépassés, téléchargement du dictionnaire et arrêt du calcul |
| Calcul local | Moteur `mfkey32v2` exécuté dans des Web Workers |

Le réglage du délai par nonce est conservé entre les visites. Le journal/Flipper et la saisie manuelle sont présentés dans deux panneaux côte à côte sur desktop, puis empilés sur petits écrans. Un tutoriel illustré responsive pour la capture NFC et l’import du journal de nonces apparaît sous les panneaux ; son cadrage s’adapte aux petits écrans.

---

## Arborescence

```
flipper-lab-nfc/
├── index.html              document de la page + garde-fou de démarrage
├── .htaccess               types MIME des modules ES (Apache / mutualisé)
├── server.py               serveur statique + repli vers la page unique
├── css/styles.css          workbench graphite, accent orange et responsive
├── assets/
│   ├── mfkey32-mark.svg    favicon Mfkey32
│   ├── foxhack-mark.svg    marque FoXhack conservée
│   ├── flipper-lab-logo.svg (asset conservé)
│   ├── favicon.png         (asset conservé)
│   ├── reader.png           illustration du tutoriel de récupération de nonces
│   └── exemple.mfkey32.log journal de démonstration
└── js/
    ├── app.js              interface Mfkey32 et orchestration
    ├── mfkey32.js          moteur mfkey32v2 (portage JS de crapto1/crypto01)
    ├── mfkey-worker.js     Web Worker : une attaque par tâche, arrêt sur délai
    ├── protobuf.js         codec protobuf minimal
    ├── flipper-serial.js   client Web Serial et session RPC du Flipper
    └── icons.js            icônes SVG inline
```

---

## Le moteur mfkey32v2

`js/mfkey32.js` est un portage fidèle, en JavaScript pur (typed arrays, `BigInt`
uniquement pour la clé de 48 bits), de :

- `mfkey32v2.c` — [github.com/equipter/mfkey32v2](https://github.com/equipter/mfkey32v2)
- `include/crypto01.c` / `crypto1.c` / `bucketsort.c` — crapto1, © bla & Proxmark3 contributors, **GPL-3**

Enchaînement : `prng_successor(nt0, 64)` → `ks2 = ar0 ⊕ suc⁶⁴(nt0)` →
`lfsr_recovery32(ks2, 0)` (tables de 2²¹ états, `extend_table_simple`, tri par seaux
et intersection, recursion `recover`) → pour chaque état candidat,
`lfsr_rollback_word ×3` → `crypto1_get_lfsr` → vérification sur la seconde
authentification (`nt1`, `nr1`, `ar1`).

**Validé** contre le binaire C de référence compilé avec gcc : résultats identiques sur
le vecteur public, sur des jeux de nonces incohérents (aucune clé), et sur 7 clés
synthétisées (aller-retour clé → nonces → clé). ~0,5 à 0,9 s par attaque dans Node,
comparable au C (~0,17 s) compte tenu de l'écart d'optimisation.

Voir [`docs/mfkey32v2.md`](docs/mfkey32v2.md) pour le détail de l'attaque et du protocole.

---

## Mise en ligne (hébergement statique)

Le livrable est 100 % statique : déposez **le contenu** de `flipper-lab-nfc/` dans le
dossier visé (par exemple `www/mfkey32/` pour <https://foxhack.fr/mfkey32/>), sans
changer l’arborescence. Tous les chemins de `index.html` sont relatifs, donc un
sous-dossier fonctionne tel quel.

```
www/mfkey32/
├── .htaccess
├── index.html
├── css/styles.css
├── assets/…
└── js/app.js  mfkey32.js  mfkey-worker.js  flipper-serial.js  protobuf.js  icons.js
```

### Types MIME — le point qui casse tout

L’application est écrite en **modules ES** (`<script type="module">`). Un navigateur
refuse d’exécuter un module dont la réponse n’est pas `text/javascript` :

```
Failed to load module script: Expected a JavaScript-or-Wasm module script but the
server responded with a MIME type of "application/octet-stream". Strict MIME type
checking is enforced for module scripts per HTML spec.
```

Résultat : page noire, sans autre symptôme. Deux protections sont en place :

1. **Aucun fichier `.mjs`** dans le livrable — le moteur s’appelle `js/mfkey32.js`,
   extension que tous les serveurs connaissent. C’est la raison pour laquelle un
   déploiement qui fonctionnait en local (`server.py` déclare le MIME `.mjs`) peut
   échouer sur un mutualisé.
2. **`.htaccess`** avec `AddType text/javascript .js .mjs` (+ json, svg, css, woff2,
   wasm), chaque directive étant enveloppée dans `<IfModule>` pour ne jamais
   provoquer d’erreur 500. Pensez à activer l’affichage des fichiers cachés dans
   votre client FTP, sinon ce fichier ne part pas.

Sur **nginx**, l’équivalent se place dans le bloc `server` :

```nginx
types {
  text/javascript js mjs;
  application/json json;
  image/svg+xml  svg svgz;
}
```

Vérification en une commande (le `Content-Type` doit être `text/javascript`) :

```bash
curl -sI https://foxhack.fr/mfkey32/js/app.js | grep -i content-type
```

### Garde-fou anti écran noir

`index.html` charge le module via `import()` dans un bloc `try/catch` et embarque un
garde-fou en script classique : si l’interface n’est pas montée (MIME refusé, fichier
manquant, erreur au démarrage, navigateur sans modules ES, ou rien après 12 s), un
panneau de diagnostic s’affiche à la place de l’écran noir. Il sonde chaque script,
affiche le `Content-Type` réellement renvoyé par le serveur, donne le correctif
`.htaccess` à copier et propose un rechargement. `js/app.js` appelle
`window.__mfkeyGuard.ready()` une fois l’interface montée, ce qui désarme le filet.

### Autres prérequis

- **HTTPS obligatoire** pour la connexion au Flipper (Web Serial) ; le calcul hors
  ligne reste disponible en HTTP.
- **Cache navigateur** : les références portent un `?v=workbench-NN` à incrémenter à
  chaque publication, sinon les visiteurs gardent l’ancien `app.js` en cache.
- Aucune réécriture d’URL n’est nécessaire : le routage se fait par hash (`#/…`).

---

## Tests

Les bancs de test vivent dans `../dev` (hors du livrable) :

```bash
cd ../dev
npm ci
npm test                 # moteur : JS vs binaire C de référence
npm run test:ui          # interface + mode hors ligne (DOM simulé)
npm run test:serial      # interface + Flipper simulé (RPC protobuf)
npm run test:deploy      # mise en ligne : MIME, .htaccess, garde-fou anti écran noir
npm run test:all         # les quatre bancs à la suite
```

Le banc `test:deploy` rejoue le scénario de l’hébergement fautif : il exécute le
garde-fou de `index.html` dans un DOM simulé avec un serveur qui renvoie
`application/octet-stream`, puis vérifie que le diagnostic s’affiche (cause, type MIME
réel de chaque script, correctif `.htaccess`) au lieu d’un écran noir.

Le harnais série rejoue toute la chaîne : `start_rpc_session` → `systemDeviceInfo` →
détection microSD → `storageRead /ext/nfc/.mfkey32.log` → cassage → fusion du
dictionnaire → `storageWrite /ext/nfc/assets/mf_classic_dict_user.nfc`.

---

## Mentions

Projet de reconstruction à but pédagogique, **sans lien avec Flipper Zero Inc.**
Le nom, le logo et la charte appartiennent à leurs ayants droit.

- Moteur : portage de [mfkey32v2](https://github.com/equipter/mfkey32v2) (GPL-3),
  basé sur `crypto01`/crapto1 de [Proxmark3](https://github.com/RfidResearchGroup/proxmark3) (GPL-3).
- Icônes `mdi-*` : [Material Design Icons](https://pictogrammers.com/library/mdi/) (Apache 2.0).
- Documentation : <https://docs.flipper.net/nfc/mfkey32>.

N'utilisez cet outil que sur des cartes et des lecteurs dont vous êtes propriétaire ou
dont vous avez l'autorisation explicite d'auditer la sécurité.
