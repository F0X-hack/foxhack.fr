#!/usr/bin/env python3
"""
Serveur statique de « FoXhack // NFC Lab — Mfkey32 ».

- sert les fichiers du répertoire courant,
- réécrit toute route inconnue vers index.html (SPA, comme le site d'origine),
- ajoute les en-têtes nécessaires aux modules ES et aux Web Workers.

Usage :  python3 server.py [port]     (port par défaut : 8080)
"""

import os
import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse

ROOT = os.path.dirname(os.path.abspath(__file__))

EXTRA_MIME = {
    ".mjs": "text/javascript",
    ".js": "text/javascript",
    ".json": "application/json",
    ".svg": "image/svg+xml",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
    ".nfc": "text/plain",
}


class Handler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, **EXTRA_MIME}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def translate_path(self, path):
        clean = unquote(urlparse(path).path)
        candidate = os.path.normpath(os.path.join(ROOT, clean.lstrip("/")))
        # route SPA : si le chemin ne correspond pas à un fichier existant,
        # on sert index.html (ex. /nfc-tools)
        if not os.path.exists(candidate) and "." not in os.path.basename(clean):
            return os.path.join(ROOT, "index.html")
        return super().translate_path(path)

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else int(os.environ.get("PORT", 8080))
    server = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print(f"FoXhack // NFC Lab : http://0.0.0.0:{port}/nfc-tools")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nArrêt du serveur.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
